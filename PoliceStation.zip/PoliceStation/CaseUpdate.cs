﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class CaseUpdate : Form
    {
        public CaseUpdate()
        {
            InitializeComponent();
            showCases();
            countCases();
            countCriminal();
            GetCriminals();
            OffNameLb.Text = Login.OffName;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void showCases()
        {
            conn.Open();
            String Query = "Select * from CaseTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, conn);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CasesDGV.DataSource = ds.Tables[0];
            conn.Close();
        }
        private void countCases()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CaseTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            TotalCasesLb.Text = dt.Rows[0][0].ToString() + "Cases";


            conn.Close();

        }

        private void countCriminal()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CriminalTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CrLbl.Text = dt.Rows[0][0].ToString() + " Arrested";

            conn.Close();

        }
        private void GetCriminals()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from CriminalTbl", conn);
            SqlDataReader Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CrCode", typeof(int));
            dt.Load(Rdr);
            CriminalCb.ValueMember = "CrCode";
            CriminalCb.DataSource = dt;
            conn.Close();
        }
        private void GetCriminalName()
        {
            conn.Open();
            string Query = "select * from CriminalTbl where CrCode=" + CriminalCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CrimNameTb.Text = dr["CrName"].ToString();
            }
            conn.Close();
        }
        private void EditBtn_Click(object sender, EventArgs e)
        {

            if (caseheadTb.Text == "" || casedetailsTb.Text == "" || TypeCb.SelectedIndex == -1 || PlaceTb.Text == "" || CrimNameTb.Text == "")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update CaseTbl set CType = @CT,CHeading = @CH,CDetails = @CD,Cplace = @CP,CDate = @CDa,Cperson = @CPer,CpersonName = @CPerN,polname = @poln where CNum = @PKey", conn);
                    cmd.Parameters.AddWithValue("@CT", TypeCb.Text);
                    cmd.Parameters.AddWithValue("@CH", caseheadTb.Text);
                    cmd.Parameters.AddWithValue("@CD", casedetailsTb.Text);
                    cmd.Parameters.AddWithValue("@CP", PlaceTb.Text);
                    cmd.Parameters.AddWithValue("@CDa", Date.Value.Date);
                    cmd.Parameters.AddWithValue("@CPer", CriminalCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CPerN", CrimNameTb.Text);
                    cmd.Parameters.AddWithValue("@poln", OffNameLb.Text);
                    cmd.Parameters.AddWithValue("@PKey",textBox1.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cases Record updated!");
                    conn.Close();
                    showCases();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CriminalCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
           GetCriminalName();
        }

        private void CriminalCb_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CaseUpdate_Load(object sender, EventArgs e)
        {

        }
    }
}
