﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class OfficerDelete : Form
    {
        public OfficerDelete()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("Please enter the Officer ID!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("delete from PoliceEmpTbl where EmpCode =@PKey", conn);
                    cmd.Parameters.AddWithValue("@PKey", textBox1.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record deleted Successfully");
                    conn.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
    }
}
