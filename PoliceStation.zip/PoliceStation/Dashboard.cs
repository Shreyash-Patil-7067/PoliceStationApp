﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            countCases();
            countOfficers();
            countCriminal();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");

        private void countOfficers()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from policeEmpTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            OffLbl.Text = dt.Rows[0][0].ToString();

            conn.Close();

        }

        private void countCases()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CaseTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CaseLbl.Text = dt.Rows[0][0].ToString();
            TotalCasesLb.Text = dt.Rows[0][0].ToString() + "Cases";


            conn.Close();

        }

        private void countCriminal()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CriminalTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CrimeLbl.Text = dt.Rows[0][0].ToString();
            CrLbl.Text = dt.Rows[0][0].ToString() + " Arrested";

            conn.Close();

        }
        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            Cases obj = new Cases();
            obj.Show();
            this.Hide();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void Dashboard_Load(object sender, EventArgs e)
        {

        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            Officer obj = new Officer();
            obj.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Criminals obj = new Criminals();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Charges obj = new Charges();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
