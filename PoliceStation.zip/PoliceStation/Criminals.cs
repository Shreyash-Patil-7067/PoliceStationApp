﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class Criminals : Form
    {
        public Criminals()
        {
            InitializeComponent();
            showCriminals();
            countCases();
            countCriminal();
            OffNameLb.Text = Login.OffName;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");
        
        private void showCriminals()
        {
            conn.Open();
            string Query = "Select * from CriminalTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query,conn);
            SqlCommandBuilder cmd = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            CriminalDGV.DataSource = ds.Tables[0];
            conn.Close();
        }
        private void countCases()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CaseTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            TotalCasesLb.Text = dt.Rows[0][0].ToString() + "Cases";


            conn.Close();

        }

        private void countCriminal()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CriminalTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CrLbl.Text = dt.Rows[0][0].ToString() + " Arrested";

            conn.Close();

        }
        private void RecordBtn_Click(object sender, EventArgs e)
        {
            if(NameTb.Text == ""||AddressTb.Text == "" || ActivityTb.Text == "")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("insert into CriminalTbl(CrName,CrAddre,CrActivi)values(@CN,@CA,@CrA)", conn);
                    cmd.Parameters.AddWithValue("@CN", NameTb.Text);
                    cmd.Parameters.AddWithValue("@CA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@CrA", ActivityTb.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Criminal Record !");
                    conn.Close();
                    showCriminals();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int Key = 0;
        private void CriminalDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            /*
            NameTb.Text = CriminalDGV.SelectedRows[0].Cells[1].Value.ToString();
            AddressTb.Text = CriminalDGV.SelectedRows[0].Cells[2].Value.ToString();
            ActivityTb.Text = CriminalDGV.SelectedRows[0].Cells[3].Value.ToString();

            if (NameTb.Text == "")
            {
                Key = 0;
            }
            else
            {
                Key = Convert.ToInt32(CriminalDGV.SelectedRows[0].Cells[0].Value.ToString());
            }*/
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if(NameTb.Text == "" || AddressTb.Text == "" || ActivityTb.Text == "")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update CriminalTbl set CrName=@PN , CrAddre=@PQ ,CrActivi=@PR where CrCode = @PKey ", conn);
                    cmd.Parameters.AddWithValue("@PN", NameTb.Text);
                    cmd.Parameters.AddWithValue("@PQ", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@PR", ActivityTb.Text);
                    cmd.Parameters.AddWithValue("@PKey", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record Updated !");
                    conn.Close();
                    showCriminals();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            Delete form = new Delete();
            form.ShowDialog();
            showCriminals();
        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();

        }

        private void label1_Click(object sender, EventArgs e)
        {
            Dashboard dashboard = new Dashboard();
            dashboard.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Officer ob = new Officer();
            ob.Show();
            this.Hide();
        }

        private void label4_Click(object sender, EventArgs e)
        {
          
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Cases obj = new Cases();    
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Charges obj = new Charges();
            obj.Show();
            this.Hide();

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void Criminals_Load(object sender, EventArgs e)
        {

        }
    }
}
