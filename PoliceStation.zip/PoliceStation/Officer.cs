﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class Officer : Form
    {
        public Officer()
        {
            InitializeComponent();
            showOfficers();
            countCriminal();
            countCases();
            OffNameLb.Text = Login.OffName;
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");

        private void showOfficers()
        {
            conn.Open();
            string Query = "Select * from PoliceEmpTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, conn);
            SqlCommandBuilder cmd = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            OfficerDGV.DataSource = ds.Tables[0];
            conn.Close();
        }
        private void countCases()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CaseTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            TotalCasesLb.Text = dt.Rows[0][0].ToString() + "Cases";


            conn.Close();

        }

        private void countCriminal()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CriminalTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CrLbl.Text = dt.Rows[0][0].ToString() + " Arrested";

            conn.Close();

        }
        private void Officer_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void RecordBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" || PhoneTb.Text == "" || DesignationCb.SelectedIndex == -1 || PasswordTb.Text == "" || PhoneTb.Text == "")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("insert into PoliceEmpTbl(EmpName,EmpAddress,EmpPhone,EmpDe,EmpPass)values(@EN,@EA,@EP,@ED,@EPa)", conn);
                    cmd.Parameters.AddWithValue("@EN", NameTb.Text);
                    cmd.Parameters.AddWithValue("@EA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@EP", PhoneTb.Text);
                    cmd.Parameters.AddWithValue("@ED", DesignationCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@EPa", PasswordTb.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Officer  Recorded!");
                    conn.Close();
                    showOfficers();
                    //Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }

        }
        int Key = 0;
        private void OfficerDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           // NameTb.Text = OfficerDGV.SelectedRows[0].Cells[1].Value.ToString();
            //AddressTb.Text = OfficerDGV.SelectedRows[0].Cells[2].Value.ToString();
            //PhoneTb.Text = OfficerDGV.SelectedRows[0].Cells[3].Value.ToString();
            //DesignationCb.SelectedItem = OfficerDGV.SelectedRows[0].Cells[4].Value.ToString();
            //PasswordTb.Text = OfficerDGV.SelectedRows[0].Cells[5].Value.ToString();

            //if (NameTb.Text == "")
            //{
              //  Key = 0;
            //}
            //else
            //{
             //   Key = Convert.ToInt32(OfficerDGV.SelectedRows[0].Cells[0].Value.ToString());
            //}
        }

        private void CancelBtn_Click(object sender, EventArgs e)
        {
            OfficerDelete form = new OfficerDelete();
            form.ShowDialog();
            showOfficers();
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (AddressTb.Text == "" || PhoneTb.Text == "" || DesignationCb.SelectedIndex == -1 || PasswordTb.Text == "" || PhoneTb.Text == "" || textBox1.Text=="")
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update PoliceEmpTbl set EmpName= @EN,EmpAddress=@EA,EmpDe = @ED,EmpPhone = @EP,EmpPass = @Epa where EmpCode = @Pkey", conn);
                    cmd.Parameters.AddWithValue("@EN", NameTb.Text);
                    cmd.Parameters.AddWithValue("@EA", AddressTb.Text);
                    cmd.Parameters.AddWithValue("@EP", PhoneTb.Text);
                    cmd.Parameters.AddWithValue("@ED", DesignationCb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@EPa", PasswordTb.Text);
                    cmd.Parameters.AddWithValue("@Pkey", textBox1.Text);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Record updated..");
                    conn.Close();
                    showOfficers();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            Login obj = new Login();
            obj.Show();
            this.Hide();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Dashboard obj = new Dashboard();
            obj.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Criminals obj = new Criminals();
            obj.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            Charges obj = new Charges();
            obj.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Hide();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Cases obj = new Cases();
            obj.Show();
            this.Hide();
        }
    }
}
