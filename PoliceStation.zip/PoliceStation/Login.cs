﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PoliceStation
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");
        public static string OffName;
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if(RoleCb.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a Role!!");
            }
            else if(RoleCb.SelectedIndex == 0)
            {

                // Admin Access
                if (UsernameTb.Text == "" && PasswordTb.Text == "")
                {
                    MessageBox.Show("Please enter both username and password ");
                }
                else if(UsernameTb.Text =="Admin" && PasswordTb.Text == "Pass123")
                {
                    OffName = UsernameTb.Text;
                    Officer obj = new Officer();
                    obj.Show();
                    this.Hide();
                }
                else if (UsernameTb.Text =="Admin" && PasswordTb.Text == "")
                {
                    MessageBox.Show("Please enter password ");

                }
                else
                {
                    MessageBox.Show("Wrong username and password!! ");
                    UsernameTb.Text = "";
                    PasswordTb.Text = "";

                }
            }
            else
            {
                conn.Open();
                SqlDataAdapter sda = new SqlDataAdapter("Select Count(*) from PoliceEmptbl where EmpName='" + UsernameTb.Text + "' and EmpPass='" + PasswordTb.Text + "'", conn);
                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows[0][0].ToString() == "1")
                {
                    OffName = UsernameTb.Text;
                    Criminals Obj = new Criminals();
                    Obj.Show();
                    this.Hide();
                    conn.Close();
                }
                else
                {
                    MessageBox.Show("Wrong Officer name or Password!!");
                    UsernameTb.Text = "";
                    PasswordTb.Text = "";
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
