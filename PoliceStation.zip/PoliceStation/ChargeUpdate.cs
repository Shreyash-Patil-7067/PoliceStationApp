﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PoliceStation
{
    public partial class ChargeUpdate : Form
    {
        public ChargeUpdate()
        {
            InitializeComponent();
            showCharges();
            countCases();
            countCriminal();
            OffNameLb.Text = Login.OffName;
            GetCase();

        }
        SqlConnection conn = new SqlConnection(@"Data Source=LAPTOP-FROV9I0I\SHREYASH;Initial Catalog=PoliceStation;Integrated Security=True");
        private void countCases()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CaseTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            TotalCasesLb.Text = dt.Rows[0][0].ToString() + "Cases";


            conn.Close();

        }

        private void countCriminal()
        {
            conn.Open();
            SqlDataAdapter sda = new SqlDataAdapter("Select count (*) from CriminalTbl", conn);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            CrLbl.Text = dt.Rows[0][0].ToString() + " Arrested";

            conn.Close();

        }
        private void showCharges()
        {
            conn.Open();
            String Query = "Select * from ChargesTbl";
            SqlDataAdapter sda = new SqlDataAdapter(Query, conn);
            SqlCommandBuilder Builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            ChargeDGV.DataSource = ds.Tables[0];
            conn.Close();
        }
        private void GetCaseName()
        {
            conn.Open();
            string Query = "select * from CaseTbl where CNum=" + CaseCb.SelectedValue.ToString() + "";
            SqlCommand cmd = new SqlCommand(Query, conn);
            DataTable dt = new DataTable();
            SqlDataAdapter sda = new SqlDataAdapter(cmd);
            sda.Fill(dt);
            foreach (DataRow dr in dt.Rows)
            {
                CaseHeadingTb.Text = dr["CHeading"].ToString();
            }
            conn.Close();
        }
        private void GetCase()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("select * from CaseTbl", conn);
            SqlDataReader Rdr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Columns.Add("CNum", typeof(int));
            dt.Load(Rdr);
            CaseCb.ValueMember = "CNum";
            CaseCb.DataSource = dt;
            conn.Close();
        }
        private void EditBtn_Click(object sender, EventArgs e)
        {
            if (CaseHeadingTb.Text == "" || ChargeSheetTb.Text == "" || RemarkTb.Text == "" || ChargeNumTb.Text =="" )
            {
                MessageBox.Show("Missing Information!!");
            }
            else
            {
                try
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("update ChargesTbl set CaseCode = @CC,CaseHeading = @CH,ChargeSheet = @CS,Remarks = @Rem,polName = @Poln where ChNum = @PKey", conn);
                    cmd.Parameters.AddWithValue("@CC", CaseCb.SelectedValue.ToString());
                    cmd.Parameters.AddWithValue("@CH", CaseHeadingTb.Text);
                    cmd.Parameters.AddWithValue("@CS", ChargeSheetTb.Text);
                    cmd.Parameters.AddWithValue("@Rem", RemarkTb.Text);
                    cmd.Parameters.AddWithValue("@PolN", OffNameLb.Text);
                    cmd.Parameters.AddWithValue("@PKey", ChargeNumTb.Text);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Cases Record updated!");
                    conn.Close();
                    showCharges();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void CaseCb_SelectionChangeCommitted(object sender, EventArgs e)
        {
            GetCaseName();
        }

        private void ChargeUpdate_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
